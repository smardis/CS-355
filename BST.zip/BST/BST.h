//
// Name: Andrew Fisher, Nathan Huckaba, Franklin Glover, Stephen Mardis
// Due Date: November 13, 2015
// Assignment: Binary Search Tree
// File Name: BST.h
// Description: This is the header file containing the node class and the 
//      binary search tree class
//

#ifndef _BST_H
#define _BST_H
#include <iostream>
using namespace std;
//========================================================================
// Node Class
//========================================================================
class BNode{
public:
    int data;
private:
    BNode* left;
    BNode* right;
    BNode();
    BNode(int d);
    BNode(int d, BNode* l, BNode* r);
    friend class BST;
};
//========================================================================
// BST Class
//========================================================================
class BST{
    BNode* root;
    bool Insert(int item, BNode*& rt);
    BNode* Remove(int item, BNode* rt);
    BNode* Succ(BNode* rt);
	int minValue(BNode* subRoot);
	int maxValue(BNode* subRoot);
    BNode* Search(int item, BNode* rt)const;
    void InOrder(BNode* rt)const;
    void PreOrder(BNode* rt)const;
    void PostOrder(BNode* rt) const;
    int countNodes(BNode* rt) const;
    int countHeight(BNode* rt) const;
    void copyBST(BNode* &newRoot, BNode* &originalRoot);
	void deleteSubTree(BNode* &rt);
public:
    BST();
    bool Insert(int item);
    bool Remove(int item);
    BNode* Search(int item)const;
    void PreOrder()const;
    void PostOrder()const;
    void InOrder()const;
    int countNodes() const;
    int countHeight() const;
    BST& operator=(BST& other);
    BST(BST &source);
	~BST();
};

#endif
