//
// Name: Andrew Fisher, Nathan Huckaba, Franklin Glover, Stephen Mardis
// Due Date: November 13, 2015
// Assignment: Binary Search Tree
// File Name: driver.cpp
// Description: This is a driver for testing the binary search tree.
//

#include <iostream>
#include "BST.h"

//========================================================================
// Main Driver
//========================================================================
int main() {
	BST b;
    int choice, x;

	cout << "Menu:" << endl;
    cout << "[1] Fill Tree" << endl << "[2] Remove an Item" << endl;
    cout << "[3] Inorder Print" << endl << "[4] Preorder Print" << endl;
    cout << "[5] PostOrder Print" << endl << "[6] Search" << endl;
    cout << "[7] Number of Nodes" << endl << "[8] Height of Tree" << endl;
	cout << "[9] Copy Constructor and Assignment Operator" << endl;
	cout << "[0] Exit" << endl;

    do
    {
    	cout << "Please choose an option: ";
    	cin >> choice;

		switch(choice){
		case 1:
            cout << "Enter numbers to fill tree, use -1 to end." << endl;
            cin >> x;
            while(x >= 0){
                b.Insert(x);
                cin >> x;
            }
			break;
		case 2:
            cout << "Enter item to be removed." << endl;
            cin >> x;
            if(b.Remove(x)){
                cout << "Item was removed from tree." << endl << endl;
            }
            else
                cout << "Item was not removed." << endl << endl;
			break;
		case 3:
			cout << endl << "InOrder:   ";
            b.InOrder();
            cout << endl << endl;
			break;
		case 4:
		    cout << endl << "PreOrder:   ";
            b.PreOrder();
            cout << endl << endl;
			break;
		case 5:
            cout << endl << "PostOrder: ";
            b.PostOrder();
            cout << endl << endl;
			break;
		case 6:
            cout << "Enter item to find in tree." << endl;
            cin >> x;
			if(b.Search(x) != NULL)
                cout << x << " was found in the tree." << endl << endl;
            else
                cout << x << " was not found in the tree." << endl << endl;
			break;
		case 7:
			cout << "The number of nodes in the tree is: " << b.countNodes() << endl << endl;
			break;
        case 8:
			cout << "The heigh of the tree is: " << b.countHeight() << endl << endl;
            break;
        case 9:
        {
        	cout << endl;
			BST c;
        	c = b;
        	cout << "Assignment Operator BST InOrder: ";
        	c.InOrder();
        	cout << endl;
        	BST d(c);
        	cout << "Copy Constructor BST InOrder: ";
        	d.InOrder();
        	cout << endl << endl;
        }
        	break;
        case 0:
        	cout << "Exiting..." << endl;
        	break;
		default:
			cout << "Incorrect choice. Please try again." << endl << endl;
			break;
	   }

    }while(choice != 0);    

	return 0;
}
