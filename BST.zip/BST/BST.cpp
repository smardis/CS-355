//
// Name: Andrew Fisher, Nathan Huckaba, Franklin Glover, Stephen Mardis
// Due Date: November 13, 2015
// Assignment: Binary Search Tree
// File Name: BST.cpp
// Description: This is the program file containing all necessary functions found
//      in the header file that are needed to navigate, print, search, and remove
//      nodes from the tree.
//

#include "BST.h"
//========================================================================
// Node Constructors by group
//========================================================================
BNode::BNode():left(NULL), right(NULL){}
BNode::BNode(int d):data(d), left(NULL), right(NULL){}
BNode::BNode(int d, BNode* l, BNode* r):data(d), left(l), right(r){}

//========================================================================
// BST Constructor by group
//========================================================================
BST::BST():root(NULL){}

//========================================================================
// BST Insert by group
//========================================================================
bool BST::Insert(int item, BNode*& rt){
    if(rt == NULL){
        rt = new BNode(item, NULL, NULL);
        return true;
    }
    else if(item < rt->data){
        Insert(item, rt->left);
        return true;
    }
    else if(item > rt->data){
        Insert(item, rt->right);
        return true;
    }
    else{
        cout << "NO DUPLICATES" << endl;
        return false;
    }
}
        
bool BST::Insert(int item){
    return Insert(item, root);
}

//========================================================================
// BST Remove by group
//========================================================================
BNode* BST::Remove(int item, BNode* rt){
    BNode* temp = NULL;
    if(rt == NULL)      //BST is empty 
        return NULL;
    if(rt->data == item){
        if(rt->right == NULL && rt->left == NULL){  //Root has no children
            delete rt;
            return NULL;
        }
        else if(rt->right == NULL){                 //Root has one child on left
            temp = rt->left;
            delete rt;
            return temp;
        }
        else if(rt->left == NULL){                  //Root has one child on right
            temp = rt->right;
            delete rt;
            return temp;
        }
        else{                                       //Root has two children
            temp = Succ(rt->right);
            rt->data = temp->data;
            rt->right = Remove(rt->data, rt->right);
            return rt;
        }
    }
    else if(item < rt->data){
        rt->left = Remove(item, rt->left);
    }
    else if(item > rt->data){
        rt->right = Remove(item, rt->right);
    }
    return rt;

}

bool BST::Remove(int item){
	if (root == NULL ) //empty BST
		return false;
	if (root->data == item){ //item to be removed is root
		if (root->left == NULL && root->right == NULL){ //root only item in tree
			delete root;
			root = NULL;
		}
		else if (root->left == NULL){//one child on right
			int newRootData = minValue(root->right);
			root->data = newRootData;
			root->right = Remove(newRootData, root->right);
		}
		else { //one child on left or two children
			int newRootData = maxValue(root->left);
			root->data = newRootData;
			root->left = Remove(newRootData, root->left);
		}
		return true;
	}
	else
    	return Remove(item, root) != NULL;
}


//========================================================================
// Remove helpers by group
//========================================================================

int BST::maxValue(BNode* subRoot) {
      if (subRoot->right == NULL)
            return subRoot->data;
      else
            return maxValue(subRoot->right);
}

int BST::minValue(BNode* subRoot) {
      if (subRoot->left == NULL)
            return subRoot->data;
      else
            return minValue(subRoot->left);
}

//========================================================================
// BST Succ by Andrew
//========================================================================
BNode* BST::Succ(BNode* rt){
    static BNode* temp;
    if(rt == NULL){
        return temp;
    }
    else{
        temp = rt;
        return Succ(rt->left);
    }
}

//========================================================================
// BST Search by group
//========================================================================
BNode* BST::Search(int item, BNode* rt)const{
    if(rt == NULL)
        return NULL;
    else if(item == rt->data)
        return rt;
    else if(item < rt->data)
        return Search(item, rt->left);
    else
        return Search(item, rt->right);
}

BNode* BST::Search(int item)const{
    Search(item, root);
}

//========================================================================
// BST PreOrder Traversal by group
//========================================================================
void BST::PreOrder()const{
    PreOrder(root);
}

void BST::PreOrder(BNode* rt)const{
    if(rt != NULL){
        cout << rt->data << " ";
        PreOrder(rt->left);
        PreOrder(rt->right);
    }
}

//========================================================================
// BST PostOrder Traversal by group
//========================================================================
void BST::PostOrder()const{
    PostOrder(root);
}

void BST::PostOrder(BNode* rt)const{
    if(rt != NULL){
        PostOrder(rt->left);
        PostOrder(rt->right);
        cout << rt->data << " ";
    }
}

//========================================================================
// BST InOrder Traversal by group
//========================================================================
void BST::InOrder()const{
    InOrder(root);
}

void BST::InOrder(BNode* rt) const{
    if(rt != NULL){
        InOrder(rt->left);
        cout << rt->data << " ";
        InOrder(rt->right);
    }
}

//========================================================================
// BST Count Nodes by Nathan
//========================================================================
int BST::countNodes(BNode * rt) const{
    if (rt == NULL)
        return 0;
    else
        return (1 + countNodes(rt->right) + countNodes(rt->left));
}
 
 
int BST::countNodes() const{
    return countNodes(root);
}

//========================================================================
// BST Count Height by Nathan
//========================================================================
int BST::countHeight() const {
    return countHeight(root);
}
 
int BST::countHeight(BNode* rt) const{
    int leftHeight = 0;
    if (rt->left != NULL)
        leftHeight = countHeight(rt->left);
         
    int rightHeight = 0;
    if (rt->right != NULL)
        rightHeight = countHeight(rt->right);
 
    if (leftHeight > rightHeight)
        return leftHeight + 1;
    else
        return rightHeight + 1;
}

//========================================================================
//Assignment operator by Nathan
//========================================================================
BST& BST::operator=(BST& other){
	if(this != &other){
		deleteSubTree(root);
		this->root = other.root;
		copyBST(root, other.root);
	}
	return *this;
}

//========================================================================
//Copy Constructor by Nathan
//========================================================================
void BST::copyBST(BNode* &newRoot, BNode* &originalRoot)
{
    if(originalRoot == NULL)
    {
        newRoot = NULL;
    }
    else
    {
        newRoot = new BNode;
        newRoot->data = originalRoot->data;
        copyBST(newRoot->left, originalRoot->left);
        copyBST(newRoot->right, originalRoot->right);
    }
}

BST::BST(BST &original)
{
    if(original.root == NULL)
        root = NULL;
    else
        copyBST(root, original.root);
}

//========================================================================
// BST Destructor by Nathan
//========================================================================
BST::~BST(){
    deleteSubTree(root);
}

void BST::deleteSubTree(BNode* &rt){
    if (rt != NULL)
    {
        deleteSubTree(rt->left);
 
        deleteSubTree(rt->right);
 
        delete rt;
        rt = NULL;
    }
}
